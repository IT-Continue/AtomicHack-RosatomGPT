import vector_searcher as vs
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup


async def handle_main(message: types.Message):
    await message.answer(
        "Привет. Я чат-бот Росатома, помогаю найти всю необходимую информацию по закупкам. Выберите кнопку, чтобы начать поиск:",
        reply_markup=keyboard_main)

    await SearchType.MAIN.set()


logging.basicConfig(level=logging.INFO)

bot = Bot(token="6773367774:AAE5GKYqbTAtebO3SuoaevC8sMHobduutUI")

dp = Dispatcher(bot, storage=MemoryStorage())

data_path = "content"


class SearchType(StatesGroup):
    VECTOR = State()
    MAIN = State()


# Main keyboard
keyboard_main = types.ReplyKeyboardMarkup(resize_keyboard=True)
buttons_main = ["Векторный поиск", "Поиск нейросеть", "Тех поддержка"]
keyboard_main.add(*buttons_main)

# Vector keyboard
keyboard_vector = types.ReplyKeyboardMarkup(resize_keyboard=True)
buttons_vector = ["Главное меню"]
keyboard_vector.add(*buttons_vector)
button_handlers_vector = {
    buttons_vector[0]: handle_main
}


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await handle_main(message)


@dp.message_handler(content_types=types.ContentType.TEXT, state=SearchType.MAIN)
async def handle_main_keyboard(message: types.Message):
    if message.text == "Векторный поиск":
        await SearchType.VECTOR.set()
        await message.answer("Вы выбрали векторный поиск, задайте ваш вопрос", reply_markup=keyboard_vector)
    elif message.text == "Поиск нейросеть":
        await message.answer("Вы выбрали поиск через нейросеть, задайте ваш вопрос", reply_markup=keyboard_main)
    elif message.text == "Тех поддержка":
        await message.answer(
            "Вы выбрали тех поддержку, напишите, ваш вопрос и первый освободившийся специалист поможет Вам",
            reply_markup=keyboard_main)


@dp.message_handler(content_types=types.ContentType.TEXT, state=SearchType.VECTOR)
async def handle_vector(message: types.Message):
    # Get the message
    user_message = message.text

    # Handle keyboard buttons
    if user_message in button_handlers_vector:
        await button_handlers_vector[user_message](message)
    else:
        print(f"Векторный поиск | Вопрос: {user_message}")

        # Send answer
        await dp.bot.send_message(message.from_user.id,
                                  f"Ответ:\n{vs.send_question(question=user_message, path=data_path)}")


if __name__ == '__main__':
    from aiogram import executor

    executor.start_polling(dp, skip_updates=True)
